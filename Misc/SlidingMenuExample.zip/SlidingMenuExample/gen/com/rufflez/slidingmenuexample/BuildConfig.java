/** Automatically generated file. DO NOT MODIFY */
package com.rufflez.slidingmenuexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}